CARSPLIT - BUOC 1 (khao sat)

Cai dat Theos tren Mac/Linux, sau do:
  make package
Copy file .deb trong thư mục packages/ sang iPhone, cai bang Sileo hoac:
  dpkg -i ten_file.deb
Roi respring / ldrestart.

Su dung:
1. Ket noi iPhone voi CarPlay (xe that hoac CarPlay Simulator).
2. Doi ~10 giay.
3. Lay file: /var/jb/var/mobile/Documents/carsplit_classes.txt
4. Gui file do (hoac phan dau) cho Claude, kem phien ban iOS + dong iPhone.

Neu file khong xuat hien: bundle id/process cua CarPlay co the khac.
Kiem tra bang: ps aux | grep -i carplay  va sua CarSplit.plist + Makefile cho dung.
