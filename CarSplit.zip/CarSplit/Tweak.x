// CarSplit - BƯỚC 1: khảo sát class CarPlay (Dopamine / rootless)
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>

static NSString *const kOut = @"/var/jb/var/mobile/Documents/carsplit_classes.txt";

static BOOL CSMatch(NSString *n) {
    for (NSString *p in @[@"CRS", @"CPS", @"CAR", @"CarPlay", @"CPUI", @"SBCar"])
        if ([n hasPrefix:p]) return YES;
    return NO;
}

static void CSDump(void) {
    unsigned int count = 0;
    Class *list = objc_copyClassList(&count);
    NSMutableString *out = [NSMutableString string];
    for (unsigned int i = 0; i < count; i++) {
        NSString *name = NSStringFromClass(list[i]);
        if (!CSMatch(name)) continue;
        const char *img = class_getImageName(list[i]);
        [out appendFormat:@"\n@interface %@ (%s)\n", name, img ?: "?"];
        unsigned int mc = 0;
        Method *ms = class_copyMethodList(list[i], &mc);
        for (unsigned int j = 0; j < mc; j++)
            [out appendFormat:@"- %@\n", NSStringFromSelector(method_getName(ms[j]))];
        free(ms);
    }
    free(list);
    [out writeToFile:kOut atomically:YES encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"[CarSplit] dumped to %@", kOut);
}

// --- Bước 2 (sẽ hoàn thiện sau khi có danh sách class) ---
typedef struct { CGRect left; CGRect right; } CSSplit;

static CSSplit CSMakeSplit(CGRect b, CGFloat ratio) {
    CGFloat w = b.size.width * ratio;
    CSSplit s;
    s.left  = CGRectMake(b.origin.x, b.origin.y, w, b.size.height);
    s.right = CGRectMake(b.origin.x + w, b.origin.y, b.size.width - w, b.size.height);
    return s;
}

// 0 = app trái, 1 = app phải: dùng để chuyển cảm ứng đúng app
static NSInteger CSPaneForPoint(CGPoint p, CGRect b, CGFloat ratio) {
    return p.x < b.origin.x + b.size.width * ratio ? 0 : 1;
}

%ctor {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 8 * NSEC_PER_SEC),
                   dispatch_get_main_queue(), ^{ CSDump(); });
}
